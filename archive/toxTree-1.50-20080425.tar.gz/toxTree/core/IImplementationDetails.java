package toxTree.core;

public interface IImplementationDetails {
	String getImplementationDetails();
}
