/*
Copyright (C) 2005-2006  

Contact: nina@acad.bg

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public License
as published by the Free Software Foundation; either version 2.1
of the License, or (at your option) any later version.
All we ask is that proper credit is given for our work, which includes
- but is not limited to - adding the above copyright notice to the beginning
of your source code files, and to any copyright notice that you may distribute
with programs based on this work.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA
*/

package mutant.rules;

import java.util.List;

import org.openscience.cdk.Atom;
import org.openscience.cdk.CDKConstants;
import org.openscience.cdk.MoleculeSet;
import org.openscience.cdk.graph.ConnectivityChecker;
import org.openscience.cdk.interfaces.IAtomContainer;
import org.openscience.cdk.interfaces.IMolecule;
import org.openscience.cdk.interfaces.IMoleculeSet;
import org.openscience.cdk.isomorphism.matchers.OrderQueryBond;
import org.openscience.cdk.isomorphism.matchers.QueryAtomContainer;
import org.openscience.cdk.isomorphism.matchers.SymbolQueryAtom;
import org.openscience.cdk.isomorphism.matchers.smarts.AnyAtom;
import org.openscience.cdk.isomorphism.matchers.smarts.AnyOrderQueryBond;
import org.openscience.cdk.isomorphism.matchers.smarts.AromaticAtom;

import toxTree.exceptions.DecisionMethodException;
import toxTree.query.FunctionalGroups;
import toxTree.query.MolFlags;
import toxTree.tree.rules.smarts.RuleSMARTSubstructure;
import toxTree.tree.rules.smarts.SMARTSException;

/*
 * 	ar-N=CH2
 *  ar-N=C=O
 * "c1c(N=C)cccc1"  
 */
public class RuleDerivedAromaticAmines extends RuleSMARTSubstructure {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5890191226995213346L;
	protected QueryAtomContainer[] groups = new QueryAtomContainer[] {group1(),group2()};

	public RuleDerivedAromaticAmines() {
		
		try {
			setContainsAllSubstructures(false);
			addSubstructure("ar-N=CH2", "a[NX2;v3]=[CX3H2]");
			addSubstructure("ar-N=C=O","a[NX2;v3]=[CX2H0]=O");
		} catch (SMARTSException x) {
			logger.error(x);
		}
		setID("ar-N=CH2");
		setTitle("Derived aromatic amines");
		setExplanation(getTitle() + " ar-N=CH2 and ar-N=C=O");
		examples[0] = "c1ccccc1";
		examples[1] = "c1c(N=C)cccc1";
	}
	
	@Override
	public boolean verifyRule(IAtomContainer mol) throws DecisionMethodException {
		if (super.verifyRule(mol)) {
		    MolFlags mf = (MolFlags) mol.getProperty(MolFlags.MOLFLAGS);
		    if (mf == null) throw new DecisionMethodException(ERR_STRUCTURENOTPREPROCESSED);

		    IMoleculeSet origin = ConnectivityChecker.partitionIntoMolecules(mol);
			IMoleculeSet sc = null;
		    for (int g=0; g < groups.length;g++) {
		    	sc = new MoleculeSet();
				deriveAmine(groups[g], origin, sc);
				if ((sc != null) && (sc.getAtomContainerCount()>0))
					origin = sc;
		    }
			if (origin != null) {
				int r = 1;
				for (int i= origin.getAtomContainerCount()-1; i>=0;i--) { 
					if (origin.getAtomContainer(i).getAtomCount()<=3)
						origin.removeAtomContainer(i);
					else {
						origin.getAtomContainer(i).setID("Residue "+Integer.toString(r));
						r++;
					}
				}
				mf.setResidues(origin);
			}
			
			return true;
		} else return false;
	}
	
	protected void deriveAmine(QueryAtomContainer q, IMoleculeSet origin,IMoleculeSet results) {
		for (int j=0; j < origin.getAtomContainerCount();j++) {
			IMoleculeSet sc = detachSubstituent(q,origin.getAtomContainer(j));
			if (sc != null)
			for (int i= sc.getAtomContainerCount()-1; i>=0;i--)  
				if (sc.getAtomContainer(i).getAtomCount()>3)
					results.addAtomContainer(sc.getAtomContainer(i));
		}
	}
	
	//aN=C=O
	public  static QueryAtomContainer group1() {
        QueryAtomContainer query = new QueryAtomContainer();
        query.setID("aN=C=O");
        SymbolQueryAtom c = new SymbolQueryAtom(new Atom("C"));
        SymbolQueryAtom o = new SymbolQueryAtom(new Atom("O"));
        SymbolQueryAtom n = new SymbolQueryAtom(new Atom("N"));
        AromaticAtom a = new AromaticAtom();
        query.addAtom(c);query.addAtom(o);query.addAtom(n);query.addAtom(a);
        query.addBond(new OrderQueryBond(c, o, CDKConstants.BONDORDER_DOUBLE));
        query.addBond(new OrderQueryBond(c, n, CDKConstants.BONDORDER_DOUBLE));
        query.addBond(new OrderQueryBond(n, a, CDKConstants.BONDORDER_SINGLE));
        c.setProperty(FunctionalGroups.DONTMARK,query.getID());
        //to be split at C=N bond
        return query;
    }    
	//aN=C=CH2
	public static QueryAtomContainer group2() {
        QueryAtomContainer query = new QueryAtomContainer();
        query.setID("aN=C=CH2");
        SymbolQueryAtom c = new SymbolQueryAtom(new Atom("C"));
        SymbolQueryAtom c1 = new SymbolQueryAtom(new Atom("C"));
        SymbolQueryAtom n = new SymbolQueryAtom(new Atom("N"));
        AromaticAtom a = new AromaticAtom();
        query.addAtom(c);query.addAtom(c1);query.addAtom(n);query.addAtom(a);
        query.addBond(new OrderQueryBond(c, c1, CDKConstants.BONDORDER_DOUBLE));
        query.addBond(new OrderQueryBond(c, n, CDKConstants.BONDORDER_DOUBLE));
        query.addBond(new OrderQueryBond(n, a, CDKConstants.BONDORDER_SINGLE));

        
        for (int i=0; i < 2; i++) {
        	SymbolQueryAtom h = new SymbolQueryAtom(new Atom("H"));
        	query.addBond(new OrderQueryBond(c1, h, CDKConstants.BONDORDER_SINGLE));
        }
        //to be split at C=N bond
        c.setProperty(FunctionalGroups.DONTMARK,query.getID());
        return query;
    } 	
	public IMoleculeSet detachSubstituent(QueryAtomContainer q, IAtomContainer c) {
		List map = FunctionalGroups.getBondMap(c,q,false);
		FunctionalGroups.markMaps(c,q,map);
		if (map == null) return null;
		return FunctionalGroups.detachGroup(c,q);
	}
}


