package mutant.rules;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import org.openscience.cdk.interfaces.IAtomContainer;

import toxTree.core.IDecisionInteractive;
import toxTree.exceptions.DecisionMethodException;
import toxTree.tree.AbstractRule;

public abstract class UserInputRule extends AbstractRule implements IDecisionInteractive {
	protected String message="";
	protected boolean interactive = true;
	protected boolean silentvalue = true;
	/**
	 * 
	 */
	private static final long serialVersionUID = 533087115478484038L;
	public UserInputRule() {
		setID("User");
		setTitle("User input");
		setExplanation("Proceed with QSARs?");
	}	
	public UserInputRule(String message) {
		this();
		setMessage(message);
	}
	public boolean verifyRule(IAtomContainer mol) throws DecisionMethodException {
		if (!interactive) return silentvalue;
		final String[] titles = {"Yes","No","Yes to all","No to all"};

		ConfirmDialog d = new ConfirmDialog(null,getTitle(),getMessage(), titles);
		d.setModal(true);
		d.setVisible(true);
		String answer= d.getAnswer();
		if (answer.equals(titles[0])) {
			return true;
		} else if (answer.equals(titles[1])) {
			return false;
		} else if (answer.equals(titles[2])) {
			setInteractive(false);
			setSilentvalue(true);
			return silentvalue;
		} else if (answer.equals(titles[3])) {
			setInteractive(false);
			setSilentvalue(false);
			return silentvalue;
		} else 
			throw new DecisionMethodException("Answer not specified");
	}
	@Override
	public boolean isImplemented() {
		return !message.equals("");
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public boolean getInteractive() {
		return interactive;
	}

	public JComponent optionsPanel(IAtomContainer atomContainer) {
		return new JLabel(message);
	}

	public void setInteractive(boolean value) {
		this.interactive = value;
		
	}
	public boolean isSilentvalue() {
		return silentvalue;
	}
	public void setSilentvalue(boolean silentvalue) {
		this.silentvalue = silentvalue;
	}	
}

class ConfirmDialog extends JDialog implements ActionListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 7492508085768486348L;
	protected String answer;
	public ConfirmDialog(JFrame parent, String title,Object message,String[] options) {
		super(parent);
		setLocationRelativeTo(parent);
		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		setTitle(title);
		getContentPane().setLayout(new BorderLayout());
		
		JPanel bottom = new JPanel(new FlowLayout());
		JButton[] optionButtons = new JButton[4];
		for (int i=0;i < optionButtons.length;i++) {
			optionButtons[i] = new JButton(options[i]);
			optionButtons[i].addActionListener(this);
			optionButtons[i].setActionCommand(options[i]);
			bottom.add(optionButtons[i]);
		}
		
		if (message instanceof Component)
			getContentPane().add((Component) message,BorderLayout.CENTER);
		else	
			getContentPane().add(new JLabel(message.toString()),BorderLayout.CENTER);
		getContentPane().add(bottom,BorderLayout.SOUTH);
		setPreferredSize(new Dimension(300,200));
		
		pack();
	}

	public void actionPerformed(ActionEvent e) {
		answer = e.getActionCommand();
		setVisible(false);
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	
}

