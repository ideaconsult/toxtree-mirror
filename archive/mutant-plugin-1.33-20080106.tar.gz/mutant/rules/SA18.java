/*
Copyright Ideaconsult Ltd. (C) 2005-2007  

Contact: nina@acad.bg

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public License
as published by the Free Software Foundation; either version 2.1
of the License, or (at your option) any later version.
All we ask is that proper credit is given for our work, which includes
- but is not limited to - adding the above copyright notice to the beginning
of your source code files, and to any copyright notice that you may distribute
with programs based on this work.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA
*/

package mutant.rules;

import java.util.List;

import org.openscience.cdk.CDKConstants;
import org.openscience.cdk.interfaces.IAtom;
import org.openscience.cdk.interfaces.IAtomContainer;
import org.openscience.cdk.interfaces.IRing;
import org.openscience.cdk.interfaces.IRingSet;
import org.openscience.cdk.ringsearch.RingPartitioner;
import org.openscience.cdk.ringsearch.SSSRFinder;

import toxTree.exceptions.DecisionMethodException;
import toxTree.tree.rules.RuleAromatic;

/**
 * TODO Reimplement PAH recognition in a more robust way, possibly by generalized Hueckel rule (Randic)
 * 
 * @author nina
 *
 */
public class SA18 extends RuleAromatic  implements IAlertCounter {
    /**
     * 
     */
    private static final long serialVersionUID = 6108780282064473735L;
    /**
     * 
     */
	IAlertCounter alertsCounter;
	
    public SA18() {
        super();
        alertsCounter = new DefaultAlertCounter();
        setID("NA18");
        setTitle("Polycyclic Aromatic Hydrocarbons");
        setExplanation(" Polycyclic Aromatic Hydrocarbons, with three or more fused rings. Does not include heterocyclic compounds");
        examples[0] = "CCN2C3=CC=CC=C3(C=1C=C(N)C=CC=12)"; //heterocyclic
        examples[1] = "[H]C=1C([H])=C([H])C=5C(C=1([H]))=C([H])C([H])=C3C=5(C([H])=C2C([H])=C([H])C(=C4C2=C3C([H])([H])C4([H])([H]))C([H])([H])[H])";
//"[H]C=1C([H])=C([H])C2=C(C=1([H]))C4=C([H])C([H])=C([H])C3=C([H])C(=C(C2=C34)N(=O)O)N(=O)O"; //"C=1C=C2C=CC3=CC=CC4=CC=C(C=1)C2=C34";   
        /*
        examples[0] = "";
        examples[1] = "O=[N+]([O-])C=4C=C2C=CC=C3C=1C=CC=CC=1C(=C23)C=4[N+](=O)[O-]";
        */
//"[H]C=1C([H])=C([H])C3=C(C=1([H]))C=2C(=C([H])C([H])=C([H])C=2C3([H])([H]))N([H])C(=O)C([H])([H])[H]";
//C1=CC=C3C(=C1)CC2=CC=CC=C23";
/*
 * C1=CC=C3C(=C1)CC2=CC=CC=C23
C=1C=CC3=C(C=1)CC2=CC=CC=C23
C=1C=CC3=C(C=1)CC=2C=CC=CC=23
 */        	
        	//"[H]C=1C([H])=C([H])C3=C(C=1([H]))C=2C(=C([H])C([H])=C([H])C=2C3([H])([H]))N([H])C(=O)C([H])([H])[H]";
//"C=1C=CC=2C(C=1)=CC=C4C=2C(=C3C=CC=CC3=C4C)C";
//"C=1C=C2C=CC3=CC=CC4=CC=C(C=1)C2=C34";   
        editable = false;

    }
    public void incrementCounter(IAtomContainer mol) {
        alertsCounter.incrementCounter(mol);
    }    
	public String getImplementationDetails() {
		StringBuffer b = new StringBuffer();
		b.append(alertsCounter.getImplementationDetails());
		b.append("<br>");
		b.append(getClass().getName());
		b.append("<ol><li>Find essential rings through SSSRFinder.findEssentialRings. This set of rings is uniquely defined.");
		b.append("<li>Split into set of fused rings. <li>For each set of fused rings verify for each ring if it is composed of aromatic atoms only.");
		b.append("If yes, the ring is considered aromatic and the counter for aromatic rings within this set of fused rings is incremented.");
		b.append("<li>If the ring is aromatic, it is verified if it contains an heteroaromatic atoms, and if yes, the counter for heteroaromatic rings is incremented.");
		b.append("<li>If the set of fused rings contains > 2 aromatic rings and no heteroaromatic rings, the rule returns true.</ol>");
		return b.toString();
	}    

    @Override
    public boolean isImplemented() {
        return true;
    }    
    
    /**
	Find essential rings through SSSRFinder.findEssentialRings. This set of rings is uniquely defined.
	Split into set of fused rings. For each set of fused rings verify for each ring if it is composed of aromatic atoms only.
	If yes, the ring is considered aromatic and the counter for aromatic rings within this set of fused rings is incremented.
	If the ring is aromatic, it is verified if it contains an heteroaromatic atoms, and if yes, the counter for heteroaromatic rings is incremented.
	
	If the set of fused rings contains > 2 aromatic rings and no heteroaromatic rings, the rule returns true.
     */
    public boolean verifyRule(IAtomContainer mol) throws DecisionMethodException {
        if (super.verifyRule(mol)) {
            SSSRFinder ssrf = new SSSRFinder(mol);
            IRingSet sssrings = ssrf.findEssentialRings();        	
            //aromaticity should already be detected by MolAnalyser
        	

        	int nr = sssrings.getAtomContainerCount(); 
            if (nr < 3) {
                logger.debug("Less than 3 rings");
                return false;
            } else {
               List ringsets = RingPartitioner.partitionRings(sssrings);
               //This partitions ring into fused rings sets
               for (int i=0; i < ringsets.size();i++) {
                    IRingSet ringset = (IRingSet) ringsets.get(i);
                    
                    if (ringset.getAtomContainerCount() < 3) continue;
                    //System.out.println("Fused rings "+ringset.getAtomContainerCount());
                    int heteroaromatic_ring_count = 0;
                    int aromatic_ring_count = 0;
                    for (int j=0; j < ringset.getAtomContainerCount();j++) {
                    		
                    		IRing ring = (IRing) ringset.getAtomContainer(j);
                    		int a = getNumberOfAromaticAtoms(ring);
                    		//System.out.println("Ring with "+ring.getAtomCount()+" atoms " + a + " aromatic");
                            if (isAromaticRing(a,ring.getAtomCount())) {
                            	aromatic_ring_count++;
                              //  System.out.println("aromatic");
                        		if (isHeterocyclic((IRing)ringset.getAtomContainer(j))) heteroaromatic_ring_count++;
                        		
                            } 
                     }
                     if (acceptRingSet(ringset, heteroaromatic_ring_count,aromatic_ring_count))  {
                        	incrementCounter(mol);
                        	return true;
                     }
                }
            }
            
            logger.debug("Aromatic fused (>=3) rings not found ");
            return false;
            
        } else {
            logger.info("Not an aromatic chemical");
            return false;
        }
    }
    protected boolean isAromaticRing(int aromaticAtoms, int allAtoms) {
    	return (allAtoms - aromaticAtoms) < 2;
    }
    protected boolean acceptRingSet(IRingSet ringset, int heteroaromaticrings, int aromaticrings) {
    	logger.debug("Heteroaromatic "+ heteroaromaticrings +" aromatic" + aromaticrings);
        return ( heteroaromaticrings==0) && (aromaticrings>2);
    }
    protected int getNumberOfAromaticAtoms(IRing ring) {
    	int ar=0;
        for (int j=0; j < ring.getAtomCount(); j++) {
            IAtom a = ring.getAtom(j);
            if (a.getFlag(CDKConstants.ISAROMATIC)) ar++;
       }
        return ar;
    }    

    protected boolean isHeterocyclic(IRing ring) {
    	boolean ok = false;
        for (int j=0; j < ring.getAtomCount(); j++) {
            IAtom a = ring.getAtom(j);
            if (!a.getSymbol().equals("C"))  {
            	ok = true;
            	break;
            }
       }
        return ok;
    }
    /*
    private IAtomContainer getPatchSubstructure() {
    		  IMolecule mol = new Molecule();
    		  IAtom a1 = mol.getBuilder().newAtom("C");
    		  a1.setPoint2d(new Point2d(1.2990381056766582, 2.25));  mol.addAtom(a1);
    		  IAtom a2 = mol.getBuilder().newAtom("C");
    		  a2.setPoint2d(new Point2d(2.5980762113533165, 1.5));  mol.addAtom(a2);
    		  IAtom a3 = mol.getBuilder().newAtom("C");
    		  a3.setPoint2d(new Point2d(0.0, 1.5));  mol.addAtom(a3);
    		  IAtom a4 = mol.getBuilder().newAtom("C");
    		  a4.setPoint2d(new Point2d(3.8971143170299745, 2.25));  mol.addAtom(a4);
    		  IAtom a5 = mol.getBuilder().newAtom("C");
    		  a5.setPoint2d(new Point2d(2.598076211353316, -4.440892098500626E-16));  mol.addAtom(a5);
    		  IAtom a6 = mol.getBuilder().newAtom("C");
    		  a6.setPoint2d(new Point2d(0.0, 0.0));  mol.addAtom(a6);
    		  IAtom a7 = mol.getBuilder().newAtom("C");
    		  a7.setPoint2d(new Point2d(-1.2990381056766582, 2.2500000000000004));  mol.addAtom(a7);
    		  IAtom a8 = mol.getBuilder().newAtom("C");
    		  a8.setPoint2d(new Point2d(5.196152422706632, 1.4999999999999996));  mol.addAtom(a8);
    		  IAtom a9 = mol.getBuilder().newAtom("C");
    		  a9.setPoint2d(new Point2d(3.897114317029974, -0.7500000000000006));  mol.addAtom(a9);
    		  IAtom a10 = mol.getBuilder().newAtom("C");
    		  a10.setPoint2d(new Point2d(1.2990381056766576, -0.7500000000000002));  mol.addAtom(a10);
    		  IAtom a11 = mol.getBuilder().newAtom("C");
    		  a11.setPoint2d(new Point2d(-1.2990381056766584, -0.7500000000000001));  mol.addAtom(a11);
    		  IAtom a12 = mol.getBuilder().newAtom("C");
    		  a12.setPoint2d(new Point2d(-2.5980762113533165, 1.5));  mol.addAtom(a12);
    		  IAtom a13 = mol.getBuilder().newAtom("C");
    		  a13.setPoint2d(new Point2d(-1.2990381056766596, 3.750000000000002));  mol.addAtom(a13);
    		  IAtom a14 = mol.getBuilder().newAtom("C");
    		  a14.setPoint2d(new Point2d(5.196152422706632, -5.551115123125783E-16));  mol.addAtom(a14);
    		  IAtom a15 = mol.getBuilder().newAtom("C");
    		  a15.setPoint2d(new Point2d(-2.598076211353316, -2.220446049250313E-16));  mol.addAtom(a15);
    		  IAtom a16 = mol.getBuilder().newAtom("C");
    		  a16.setPoint2d(new Point2d(-3.897114317029974, 2.2499999999999982));  mol.addAtom(a16);
    		  IAtom a17 = mol.getBuilder().newAtom("C");
    		  a17.setPoint2d(new Point2d(-2.5980762113533187, 4.500000000000001));  mol.addAtom(a17);
    		  IAtom a18 = mol.getBuilder().newAtom("C");
    		  a18.setPoint2d(new Point2d(-3.8971143170299762, 3.7499999999999987));  mol.addAtom(a18);
    		  IBond b1 = mol.getBuilder().newBond(a1, a2, 2.0);
    		  mol.addBond(b1);
    		  IBond b2 = mol.getBuilder().newBond(a1, a3, 1.0);
    		  mol.addBond(b2);
    		  IBond b3 = mol.getBuilder().newBond(a2, a4, 1.0);
    		  mol.addBond(b3);
    		  IBond b4 = mol.getBuilder().newBond(a2, a5, 1.0);
    		  mol.addBond(b4);
    		  IBond b5 = mol.getBuilder().newBond(a6, a3, 1.0);
    		  mol.addBond(b5);
    		  IBond b6 = mol.getBuilder().newBond(a7, a3, 2.0);
    		  mol.addBond(b6);
    		  IBond b7 = mol.getBuilder().newBond(a4, a8, 2.0);
    		  mol.addBond(b7);
    		  IBond b8 = mol.getBuilder().newBond(a9, a5, 1.0);
    		  mol.addBond(b8);
    		  IBond b9 = mol.getBuilder().newBond(a5, a10, 2.0);
    		  mol.addBond(b9);
    		  IBond b10 = mol.getBuilder().newBond(a10, a6, 1.0);
    		  mol.addBond(b10);
    		  IBond b11 = mol.getBuilder().newBond(a6, a11, 2.0);
    		  mol.addBond(b11);
    		  IBond b12 = mol.getBuilder().newBond(a12, a7, 1.0);
    		  mol.addBond(b12);
    		  IBond b13 = mol.getBuilder().newBond(a7, a13, 1.0);
    		  mol.addBond(b13);
    		  IBond b14 = mol.getBuilder().newBond(a8, a14, 1.0);
    		  mol.addBond(b14);
    		  IBond b15 = mol.getBuilder().newBond(a14, a9, 2.0);
    		  mol.addBond(b15);
    		  IBond b16 = mol.getBuilder().newBond(a11, a15, 1.0);
    		  mol.addBond(b16);
    		  IBond b17 = mol.getBuilder().newBond(a15, a12, 2.0);
    		  mol.addBond(b17);
    		  IBond b18 = mol.getBuilder().newBond(a12, a16, 1.0);
    		  mol.addBond(b18);
    		  IBond b19 = mol.getBuilder().newBond(a13, a17, 2.0);
    		  mol.addBond(b19);
    		  IBond b20 = mol.getBuilder().newBond(a18, a16, 2.0);
    		  mol.addBond(b20);
    		  IBond b21 = mol.getBuilder().newBond(a17, a18, 1.0);
    		  mol.addBond(b21);
    		  return mol;
  		}
		*/
}


