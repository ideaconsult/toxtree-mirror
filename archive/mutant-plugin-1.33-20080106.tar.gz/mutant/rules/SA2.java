/*
Copyright Ideaconsult Ltd. (C) 2005-2007  

Contact: nina@acad.bg

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public License
as published by the Free Software Foundation; either version 2.1
of the License, or (at your option) any later version.
All we ask is that proper credit is given for our work, which includes
- but is not limited to - adding the above copyright notice to the beginning
of your source code files, and to any copyright notice that you may distribute
with programs based on this work.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA
*/

package mutant.rules;

import toxTree.tree.rules.smarts.SMARTSException;

/**
 * TODO Furthermore, the possibility for the alkyl chains to have halogen substituents, should be added.
 * @author nina
 *
 */
public class SA2 extends StructureAlertCDK {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8584645139767927034L;
	public static String SA2_sulphonic = "S([!$([OH1,SH1])])(=O)(=O)O([C&H3,$([CH2][CH3]),$([CH2][CH2][CH3]),$([CH]([CH3])[CH3]),$([CH2][CH2][CH2][CH3]),$([CH2][CH]([CH3])[CH3]),$([C]([CH3])([CH3])[CH3]),$([CH]([CH3])[CH2][CH3]),$([CH2]c1ccccc1)])";
	public static String SA2_phosphonic = "P(=O)([!$([OH1,SH1])])(O([C&H3,$([CH2][CH3]),$([CH2][CH2][CH3]),$([CH]([CH3])[CH3]),$([CH2][CH2][CH2][CH3]),$([CH2][CH]([CH3])[CH3]),$([C]([CH3])([CH3])[CH3]),$([CH]([CH3])[CH2][CH3]),$([CH2]c1ccccc1)]))O([C&H3,$([CH2][CH3]),$([CH2][CH2][CH3]),$([CH]([CH3])[CH3]),$([CH2][CH2][CH2][CH3]),$([CH2][CH]([CH3])[CH3]),$([C]([CH3])([CH3])[CH3]),$([CH]([CH3])[CH2][CH3]),$([CH2]c1ccccc1)])";
	/**
	 * Alkyl (C<5) or benzyl ester of sulphonic or phosphonic acid.
	 */
	public SA2() {
		try {
			/*
			 * $([CH2][CH3]) ethyl
			 * $([CH2][CH2][CH3])  propyl
			 * $([CH]([CH3])[CH3])  isopropyl
			 * $([CH2][CH2][CH2][CH3])  butyl
			 * $([CH2][CH]([CH3])[CH3])  butyl
			 * $([C]([CH3])([CH3])[CH3])  butyl
			 * $([CH]([CH3])[CH2][CH3])  butyl
			 * $([CH2]c1ccccc1) benzyl
			 */
			addSubstructure("Alkyl ester of sulphonic acid", SA2_sulphonic	);
			addSubstructure("Alkyl ester of phosphonic acid",SA2_phosphonic );			
			setID("NA2");
			setTitle("Alkyl (C<5) or benzyl ester of sulphonic or phosphonic acid");
			setExplanation("Methyl, ethyl, propyl, butyl or benzyl esters of sulphonic or phosphonic acid. <br>P(=O)(O)(O)R or S(=O)(O)(O)R where R is not S or O <br> The alkyl chains can have halogen substituents.");
			
			examples[0] = "CCC(C)OP(O)(=O)OC(C)CCC"; //"CCC(C)OP(C)(=O)OC(C)CCC";
			examples[1] = "CCC(C)OP(C)(=O)OC(C)CC";	
			editable = false;
		
		} catch (SMARTSException x) {
			logger.error(x);
		}
		
	}

}


