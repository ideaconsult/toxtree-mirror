package mutant.test.descriptors;

import junit.framework.TestCase;
import mutant.descriptors.AromaticAmineSubstituentsDescriptor;

import org.openscience.cdk.interfaces.IAtomContainer;
import org.openscience.cdk.qsar.DescriptorValue;
import org.openscience.cdk.qsar.result.DoubleArrayResult;
import org.openscience.cdk.qsar.result.IDescriptorResult;

import toxTree.core.HueckelAromaticityDetector;
import toxTree.query.FunctionalGroups;

public class AromaticAmineSubstituentsDescriptorTest extends TestCase {
	public void test() {
    	try {
    		AromaticAmineSubstituentsDescriptor d = new AromaticAmineSubstituentsDescriptor();
    		IAtomContainer a = FunctionalGroups.createAtomContainer("c1(CC)c(O)c(Cl)c(P(=O)(F)F)c(N)c(S)1", true);
    		HueckelAromaticityDetector.detectAromaticity(a);
			DescriptorValue value = d.calculate(a);
			IDescriptorResult r = value.getValue();
			if (r instanceof DoubleArrayResult) {

				for (int i=0; i < value.getNames().length;i++) {
					System.out.print(value.getNames()[i]);
					System.out.print(" = ");
					
					System.out.println(((DoubleArrayResult)r).get(i));
					
				}
			} else System.out.println(r.getClass().getName());
    	} catch (Exception x) {
    		x.printStackTrace();
    		fail(x.getMessage());
    	}

	}
	public void testAmineGroupSubstituent() {
		fail("verify how substituted amine group should be treated (params of amine group + substituent, only substituent, largest substituent, average, etc.)");
	}
}
