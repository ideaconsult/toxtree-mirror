package mutant.test.descriptors;

import junit.framework.TestCase;
import mutant.descriptors.DescriptorBridgedBiphenyl;

import org.openscience.cdk.exception.CDKException;
import org.openscience.cdk.interfaces.IAtomContainer;
import org.openscience.cdk.isomorphism.matchers.QueryAtomContainer;
import org.openscience.cdk.qsar.DescriptorValue;
import org.openscience.cdk.qsar.result.BooleanResult;

import toxTree.core.HueckelAromaticityDetector;
import toxTree.query.FunctionalGroups;

public class DescriptorBridgedBiphenylTest extends TestCase {

	public void testBridgedBiphenyl() {
		QueryAtomContainer q = DescriptorBridgedBiphenyl.bridgedBiphenyl();
		assertEquals(13,q.getAtomCount());
		assertEquals(14,q.getBondCount());
	}
	public void testCalculate() {
		DescriptorBridgedBiphenyl d = new DescriptorBridgedBiphenyl();
		Object[][] test = new Object[][] {
				{"c1cc(ccc1Oc2ccc(cc2)",true},
				{"c1cc(ccc1Cc2ccc(cc2)(NCCC)",true},
				{"c1cc(ccc1c2ccc(cc2)",false},
				{"c1cc(ccc1OCc2ccc(cc2)",false},
		};
		try {
			for (int i=0; i < test.length;i++) {
				IAtomContainer ac = FunctionalGroups.createAtomContainer(test[i][0].toString(), true);
				HueckelAromaticityDetector.detectAromaticity(ac);
				
				BooleanResult r = (BooleanResult) ((DescriptorValue) d.calculate(ac)).getValue();
				assertEquals(
						new Boolean(test[i][1].toString()).booleanValue(),
						r.booleanValue());

				//System.out.println(test[i][0]+"\t"+r.booleanValue());
			}
		} catch (CDKException x) {
			fail(x.getMessage());
		}
	}
}
