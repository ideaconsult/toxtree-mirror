package mutant.test.descriptors;

import junit.framework.TestCase;
import mutant.descriptors.DescriptorIDist;

import org.openscience.cdk.exception.CDKException;
import org.openscience.cdk.interfaces.IAtomContainer;
import org.openscience.cdk.qsar.DescriptorValue;
import org.openscience.cdk.qsar.result.IntegerResult;

import toxTree.core.HueckelAromaticityDetector;
import toxTree.query.FunctionalGroups;

public class DescriptorIDistTest extends TestCase {

	public void testCalculate() {
		DescriptorIDist d = new DescriptorIDist();
		Integer found = new Integer(1);
		Integer notfound = new Integer(0);
		Object[][] test = new Object[][] {
				{"NC=6C=CC2C(=Cc1cc(ccc12)C5C3CC4CC5CC(C3)C4)C=6",found},
				{"Nc1ccc(cc1)c2cc(cc(c2)C(F)(F)F)C(F)(F)F",found},
				
				{"Nc1ccc(cc1)c2ccc(CCCC)cc2",found},
				{"Nc1ccc(cc1)c2ccc(cc2)C(C)(C)C",found},
				{"Nc1ccc(cc1)c2ccc(cc2)C(F)(F)F",found},
				{"C1=CC(=CC(=C1)C(F)(F)F)C2=CC=C(C=C2)N",found},
				
				{"Oc1ccc2C=C3CC(N)C=CC3(c2(c1))",notfound},

				{"c1cc(ccc1c2ccc(cc2)",notfound},
				{"c1cc(ccc1OCc2ccc(cc2)",notfound},
		};
		try {
			for (int i=0; i < test.length;i++) {
				IAtomContainer ac = FunctionalGroups.createAtomContainer(test[i][0].toString(), true);
				HueckelAromaticityDetector.detectAromaticity(ac);
				
				DescriptorValue v = (DescriptorValue) d.calculate(ac);
				assertEquals(1,v.getNames().length);
				assertEquals("Idist",v.getNames()[0]);
				
				IntegerResult r = (IntegerResult) v.getValue();
				assertEquals(
						((Integer)test[i][1]).intValue(),
						r.intValue());

				//System.out.println(test[i][0]+"\tIdist="+r.intValue());
			}
		} catch (CDKException x) {
			fail(x.getMessage());
		}		
	}
	public void test() {
		fail("verify if this is the correct implementation");
	}

}
