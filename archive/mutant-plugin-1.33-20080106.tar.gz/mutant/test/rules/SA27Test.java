package mutant.test.rules;

import toxTree.core.IDecisionRule;
import mutant.rules.SA27;
import mutant.test.TestMutantRules;

public class SA27Test extends TestMutantRules {

	@Override
	protected IDecisionRule createRuleToTest() throws Exception {
		return new SA27();
	}
	@Override
	public String getHitsFile() {
		return "NA27/sa2_l_iss2.sdf";
	}
	@Override
	public String getResultsFolder() {
		return "NA27";
	}
	
	public void testSO3H() throws Exception {
			assertFalse(verifyRule(ruleToTest,"CCC=1C=C(C(=CC=1[N+](=O)[O-])C(CCO)CCO)S(O)(=O)=O"));
	}
	public void testSO3HSmarts() throws Exception{
			assertTrue(
					applySmarts("[$(a(N(O)=O):a[#16X4](=[OX1])(=[OX1])[OX2H1]),$(a(N(O)=O):a:a[#16X4](=[OX1])(=[OX1])[OX2H1]),$(a(N(O)=O):a:a:a[#16X4](=[OX1])(=[OX1])[OX2H1]),$(a(N(O)=O):a:a:a:a[#16X4](=[OX1])(=[OX1])[OX2H1])]",
				"CCC=1C=C(C(=CC=1[N+](=O)[O-])C(CCO)CCO)S(O)(=O)=O")
				);
	}
    public void test_ortho_carboxylicacid() throws Exception {
        assertFalse(verifyRule(ruleToTest,"O=[N+]([O-])C=1C=CC=CC=1(C(O)=O)"));  
       
    }

}
