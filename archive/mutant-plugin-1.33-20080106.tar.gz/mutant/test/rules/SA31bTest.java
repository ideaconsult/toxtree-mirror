package mutant.test.rules;

import mutant.rules.SA31b;
import mutant.test.TestMutantRules;
import toxTree.core.IDecisionRule;

public class SA31bTest extends TestMutantRules {

	@Override
	protected IDecisionRule createRuleToTest() throws Exception {
		return new SA31b();
	}
	@Override
	public String getHitsFile() {
		return "NA31b/HaloPAH.sdf";
	}
	@Override
	public String getResultsFolder() {
		return "NA31b";
	}
	
}
