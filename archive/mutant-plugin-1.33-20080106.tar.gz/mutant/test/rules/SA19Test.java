/*
Copyright Ideaconsult Ltd. (C) 2005-2007  

Contact: nina@acad.bg

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public License
as published by the Free Software Foundation; either version 2.1
of the License, or (at your option) any later version.
All we ask is that proper credit is given for our work, which includes
- but is not limited to - adding the above copyright notice to the beginning
of your source code files, and to any copyright notice that you may distribute
with programs based on this work.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA
*/

package mutant.test.rules;

import org.openscience.cdk.interfaces.IAtomContainer;

import toxTree.core.IDecisionRule;
import toxTree.query.FunctionalGroups;
import toxTree.query.MolAnalyser;
import mutant.rules.SA19;
import mutant.test.TestMutantRules;

public class SA19Test extends TestMutantRules {
	@Override
	protected IDecisionRule createRuleToTest() throws Exception {
		return new SA19();
	}
	@Override
	public String getHitsFile() {
		return "NA19/heteroPAH_fixed.sdf";
	}
	@Override
	public String getResultsFolder() {
		return "NA19";
	}
    public void testAromaticity() throws Exception {
    	assertEquals(10,printAromaticity());
    }
    
    public void testPeroxide() {
        IAtomContainer c = FunctionalGroups.createAtomContainer("C=1C=CC=2C=C3C=C4C=C5OC5(=CC4(=CC3(=CC=2(C=1))))",true);
        
        try {
            MolAnalyser.analyse(c);
            assertFalse(ruleToTest.verifyRule(c));
        } catch (Exception x) {
            fail(x.getMessage());
        }

    }    
    
    

}


