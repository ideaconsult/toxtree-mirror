/*
Copyright Ideaconsult Ltd. (C) 2005-2007  

Contact: nina@acad.bg

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public License
as published by the Free Software Foundation; either version 2.1
of the License, or (at your option) any later version.
All we ask is that proper credit is given for our work, which includes
- but is not limited to - adding the above copyright notice to the beginning
of your source code files, and to any copyright notice that you may distribute
with programs based on this work.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA
*/

package mutant.test;

import java.io.FileReader;

import junit.framework.TestCase;
import mutant.descriptors.AromaticAmineSubstituentsDescriptor;
import mutant.descriptors.SubstituentExtractor;

import org.openscience.cdk.Bond;
import org.openscience.cdk.CDKConstants;
import org.openscience.cdk.DefaultChemObjectBuilder;
import org.openscience.cdk.exception.CDKException;
import org.openscience.cdk.interfaces.IAtom;
import org.openscience.cdk.interfaces.IAtomContainer;
import org.openscience.cdk.interfaces.IAtomContainerSet;
import org.openscience.cdk.isomorphism.matchers.QueryAtomContainer;

import toxTree.core.HueckelAromaticityDetector;
import toxTree.io.MyIteratingMDLReader;
import toxTree.query.FunctionalGroups;
import toxTree.tree.rules.LookupFile;

public class SubstituentsTest extends TestCase {
	public void test() {
		try {
			
			//LookupFile lookup = new LookupFile("plugins/v 1.11/mutant/src/mutant/descriptors/substituents.sdf");
			LookupFile lookup = new LookupFile("substituents.sdf");
			lookup.setUseCache(false);
			lookup.setCheckAromaticity(false);
			
			
			long now;
			IAtomContainer a;
			
			
			a = FunctionalGroups.createAtomContainer("[*]C1=CC=CO1", true);
			now = System.currentTimeMillis();
			assertTrue(lookup.find(a));
			System.out.println(System.currentTimeMillis()-now);

			a = FunctionalGroups.createAtomContainer("[*]C(C1=C([H])C([H])=C([H])C([H])=C1([H]))(C2=C([H])C([H])=C([H])C([H])=C2([H]))C3=C([H])C([H])=C([H])C([H])=C3([H])", true);
			now = System.currentTimeMillis();
			assertTrue(lookup.find(a));
			System.out.println(System.currentTimeMillis()-now);			
			
			


			
			a = FunctionalGroups.createAtomContainer("[*]C1CCC1", true);
			now = System.currentTimeMillis();
			assertTrue(lookup.find(a));
			System.out.println(System.currentTimeMillis()-now);

			a = FunctionalGroups.createAtomContainer("[*]P(=O)(F)F", true);
			now = System.currentTimeMillis();
			assertTrue(lookup.find(a));
			System.out.println(System.currentTimeMillis()-now);			
			
			a = FunctionalGroups.createAtomContainer("[*]C=1C=CC2=CC=CC=C2(C=1)", true);
			//HueckelAromaticityDetector.detectAromaticity(a);
			now = System.currentTimeMillis();
			assertTrue(lookup.find(a));
			System.out.println(System.currentTimeMillis()-now);

			a = DefaultChemObjectBuilder.getInstance().newAtomContainer();
			IAtom a1 = DefaultChemObjectBuilder.getInstance().newAtom("O");
			IAtom a2 = DefaultChemObjectBuilder.getInstance().newAtom("R");
			IAtom a3 = DefaultChemObjectBuilder.getInstance().newAtom("H");
			a.addAtom(a1);a.addAtom(a2);a.addAtom(a3);
			a.addBond(new Bond(a1,a2,CDKConstants.BONDORDER_SINGLE));
			a.addBond(new Bond(a1,a3,CDKConstants.BONDORDER_SINGLE));
			
			//a = FunctionalGroups.createAtomContainer("[*]O", true);
			//HueckelAromaticityDetector.detectAromaticity(a);
			now = System.currentTimeMillis();
			IAtomContainer mol = lookup.lookup(a);
			assertNotNull(mol);
			System.out.println(System.currentTimeMillis()-now);
			assertEquals(0.28,Double.parseDouble(mol.getProperty("MR").toString()));
			
		} catch (Exception x) {
			x.printStackTrace();
			fail(x.getMessage());
		}
	}
	public void testAll() {
		try {
			
			//LookupFile lookup = new LookupFile("plugins/v 1.11/mutant/src/mutant/descriptors/substituents.sdf");
			LookupFile lookup = new LookupFile("substituents.sdf");
			lookup.setUseCache(false);
			lookup.setCheckAromaticity(true);
			
			try {
				MyIteratingMDLReader reader = new MyIteratingMDLReader(new FileReader("substituents.sdf"),DefaultChemObjectBuilder.getInstance());
				int record = 0;
				while (reader.hasNext()) {
					Object o = reader.next();
					if (o instanceof IAtomContainer) {
						boolean aromatic = HueckelAromaticityDetector.detectAromaticity((IAtomContainer)o);
						long now = System.currentTimeMillis();
						System.out.print(record);
						System.out.print('\t');
						System.out.print(((IAtomContainer)o).getProperty("SMILES"));
						System.out.print('\t');
						System.out.print(aromatic);
						System.out.print('\t');
						if (lookup.find((IAtomContainer)o)) {
							System.out.println(System.currentTimeMillis()-now);
						} else System.out.println("not found"); 
						record++;

					}
					
				}
				assertEquals(282,record);
			} catch (Exception x) {
				fail(x.getMessage());
			}
			
		} catch (Exception x) {
			x.printStackTrace();
			fail(x.getMessage());
		}
	}
	
	/*
	public void test1() {
		try {
			QueryAtomContainer q = aromaticAmine();
			//P(=O)(F)F
			IAtomContainer a = FunctionalGroups.createAtomContainer("c1(CC)c(O)c(Cl)c(P(=O)(F)F)c(N)c(S)1", true);
			//IAtomContainer a = FunctionalGroups.createAtomContainer("c1ccc(P(=O)(F)F)c(N)c1", true);
			HueckelAromaticityDetector.detectAromaticity(a);
			if (markAtomsInRing(a, q)) {
					IAtom anchor = null;
					for (int i=0; i < a.getAtomCount();i++) {
						IAtom atom = a.getAtom(i);
						System.out.println(atom.getSymbol() + "\t" + atom.getProperty(FunctionalGroups.RING_NUMBERING));
//						if ("O".equals(atom.getSymbol())) assertEquals(3,atom.getProperty(FunctionalGroups.RING_NUMBERING));
						if ("Cl".equals(atom.getSymbol())) assertEquals(2,atom.getProperty(FunctionalGroups.RING_NUMBERING));
						if ("P".equals(atom.getSymbol())) assertEquals(1,atom.getProperty(FunctionalGroups.RING_NUMBERING));
						if ("S".equals(atom.getSymbol())) assertEquals(1,atom.getProperty(FunctionalGroups.RING_NUMBERING));
						if ("C".equals(atom.getSymbol()) &&
								(atom.getProperty(FunctionalGroups.RING_NUMBERING) != null) &&
								atom.getProperty(FunctionalGroups.RING_NUMBERING).equals(1)) {
							anchor = atom;
						}
						
					}	
					assertNotNull(anchor);
					SSSRFinder ssrf = new SSSRFinder(a);
					IRingSet rs = ssrf.findSSSR();
					rs = rs.getRings(anchor);
					for (int r=0; r < rs.getAtomContainerCount();r++) {
				        IAtomContainer mc = cloneDiscardRingAtomAndBonds(a,(IRing)rs.getAtomContainer(r));
				        IMoleculeSet  s = ConnectivityChecker.partitionIntoMolecules(mc);
						
						int substituents = enumerateSubstituents(s);
						assertTrue(substituents>0);
						System.out.println("\tsubstituents\t"+substituents);
					}
			} else 
					fail("Aromatic amine not found");
		} catch (Exception x) {
			x.printStackTrace();
			fail(x.getMessage());
		}
	}
	*/
	protected int enumerateSubstituents(IAtomContainerSet s) throws Exception {
		int substituents = 0;
		LookupFile lookup = new LookupFile("plugins/v 1.11/mutant/src/mutant/descriptors/substituents.sdf");
		lookup.setUseCache(true);
		lookup.setCheckAromaticity(false);
		
		for (int k = 0; k < s.getAtomContainerCount(); k++) {
			System.out.println("Substituent\t"+k);
			IAtomContainer m = s.getAtomContainer(k);
		    if (m!=null) {
			    if ((m.getAtomCount() == 1) && (m.getAtom(0).getSymbol().equals("H"))) continue;
			    
			    Object place = null;
			    int[] p = new int[m.getAtomCount()];	    				    
			    for (int j=0;j <m.getAtomCount();j++) {
			    	p[j] = -1;
			    	place = m.getAtom(j).getProperty(FunctionalGroups.RING_NUMBERING);
			    	if (place != null) {
			    		p[j] = ((Integer) place).intValue();
			    		/*
			    		 * 
Ring substituent at place	2	C	size	8
Ring substituent at place	3	O	size	3
Ring substituent at place	2	Cl	size	2
Ring substituent at place	1	P	size	5
Ring substituent at place	1	S	size	3
			    		 */
			    		System.out.println("Ring substituent at place\t"+p[j]+"\t"+m.getAtom(j).getSymbol() + "\tsize\t"+m.getAtomCount());
			    		assertTrue(lookup.find(m));
					    substituents++;
			    	}
			    } 
			    	

			    

		    }
		}
		return substituents;
	}
	
    public void testAromaticAmine() {
    	try {
        QueryAtomContainer q = AromaticAmineSubstituentsDescriptor.aromaticAmine();
    	IAtomContainer mol = FunctionalGroups.createAtomContainer("c1ccc(N)cc1",true);
    	HueckelAromaticityDetector.detectAromaticity(mol);
    	assertTrue(FunctionalGroups.hasGroup( mol, q) );
    	} catch (CDKException x) {
    		fail(x.getMessage());
    	}
    }    
    
    
    public void testSubstituentExtractor() {
    	try {
	    	SubstituentExtractor extractor = new SubstituentExtractor(AromaticAmineSubstituentsDescriptor.aromaticAmine()); 
			IAtomContainer a = FunctionalGroups.createAtomContainer("c1(CC)c(O)c(Cl)c(P(=O)(F)F)c(NC)c(S)1", true);
			HueckelAromaticityDetector.detectAromaticity(a);
			IAtomContainerSet set = extractor.extractSubstituents(a);
			assertEquals(6,enumerateSubstituents(set));
    	} catch (Exception x) {
    		x.printStackTrace();
    		fail(x.getMessage());
    	}
	
    }

}


