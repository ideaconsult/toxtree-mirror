/*
Copyright Ideaconsult Ltd. (C) 2005-2007  

Contact: nina@acad.bg

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public License
as published by the Free Software Foundation; either version 2.1
of the License, or (at your option) any later version.
All we ask is that proper credit is given for our work, which includes
- but is not limited to - adding the above copyright notice to the beginning
of your source code files, and to any copyright notice that you may distribute
with programs based on this work.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA
*/

package mutant;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.util.Observable;

import mutant.rules.MutantTreeResult;

import toxTree.core.IDecisionResult;
import toxTree.exceptions.DecisionMethodException;
import toxTree.exceptions.DecisionResultException;
import toxTree.tree.CategoriesList;
import toxTree.tree.DecisionNodesFactory;
import toxTree.tree.DecisionNodesList;
import toxTree.tree.TreeResult;
import toxTree.tree.UserDefinedTree;

/**
 * 

1)check if the structure is an aromatic amine , if yes run QSAR6 and QSAR8 for
aromatic amines; if not an aromatic amine go to 3)

2)if outcome from QSAR6 is positive, assign label "Potential mutagen in Salmonella typhimurium TA100"; if  QSAR8 is positive, assign label "Potential carcinogen", if not go to 3)

3)check if it is a,b unsaturated aldehyde, if yes run QSAR13 if no, go to 5)

4) if outcome from QSAR13 is positive, assign label "Potential mutagen in Salmonella typhimurium TA100" if
no, go to 5)

5) verify SA 

6) if at least one alert has fired, then assign label "Alert for potential
carcinogenicity", otherwise assign label "No alerts " 

Regarding Point 6, I hope to be able to discriminate between "Alert for potential genotoxic carcinogenicity" and "Alert for potential non-genotoxic carcinogenicity" (which means two types of SAs).

 * @author nina
 * @modified 04/07/2007
 *
 */
public class MutantRules extends UserDefinedTree {
	/**
     * Comment for <code>serialVersionUID</code>
     */
    private static final long serialVersionUID = 0;
    protected boolean residuesIDVisible;
    
	public final static transient String[] c_rules = { 
			"mutant.rules.RuleAlertsForCarcinogenicity", // Rule  1			
			"mutant.rules.SA1", //2
			"mutant.rules.SA2", //3
			"mutant.rules.SA3", //4
			"mutant.rules.SA4", //5
			"mutant.rules.SA5", //6
			"mutant.rules.SA6", //7
			"mutant.rules.SA7", //8
			"mutant.rules.SA8", //9
			"mutant.rules.SA9", //10
			"mutant.rules.SA10", //11
			"mutant.rules.SA11", //12
			"mutant.rules.SA12", //13
			"mutant.rules.SA13", //14
			"mutant.rules.SA14", //15
			"mutant.rules.SA15", //16
			"mutant.rules.SA16", //17
			"mutant.rules.SA18", //18
			"mutant.rules.SA19", //19 
			"mutant.rules.SA21", //20
			"mutant.rules.SA22", //21
			"mutant.rules.SA23", //22
			"mutant.rules.SA24", //23
			"mutant.rules.SA25", //24
			"mutant.rules.SA26", //25
			"mutant.rules.SA27", //26
			"mutant.rules.SA28", //27
			"mutant.rules.SA28bis", //28
			"mutant.rules.SA28ter",		 //29	
			"mutant.rules.SA29",	//30
			"mutant.rules.SA30", //31
			"toxTree.tree.rules.RuleVerifyAlertsCounter", //32
			"mutant.rules.RuleAlertsNongenotoxicCarcinogenicity", //33
			"mutant.rules.SA17", //34 nongenotoxic
			"mutant.rules.SA20", //35 nongenotoxic
			"mutant.rules.SA31a", //36 nongenotoxic
			"mutant.rules.SA31b", //37 nongenotoxic
			"mutant.rules.SA31c", //38 nongenotoxic
			"mutant.rules.VerifyAlertsNongenotoxic", //39
			"mutant.rules.RuleABUnsaturatedAldehyde", //is a,b unsaturated aldehyde Rule 40
			"mutant.rules.UserInputABUnsaturatedAldehyde", //41
			"mutant.rules.RuleDAMutagenicityABUnsaturatedAldehydes", //QSAR13 Rule 42
			"mutant.rules.RuleAromaticDiazo", //43
			"mutant.rules.RuleDerivedAromaticAmines", //44 (ii)
			"mutant.rules.RuleAromaticAmineNoSulfonicGroup", //is aromatic amine Rule  45
			"mutant.rules.UserInputAromaticAmine", //46
			"mutant.rules.RuleDACancerogenicityAromaticAmines", //QSAR8  Rule 47
			"mutant.rules.RuleDAMutagenicityAromaticAmines" //QSAR6 Rule 48
			};
	private final static transient int c_transitions[][] ={
		//{if no go to, if yes go to, assign if no, assign if yes}
		{2,2,0,0}, //Rule 1  1
		{3,3,0,0}, //sa1 2
		{4,4,0,0}, //sa2 3
		{5,5,0,0}, //sa3  4
		{6,6,0,0}, //sa4 5
		{7,7,0,0}, //sa5 6
		{8,8,0,0}, //sa6 7
		{9,9,0,0}, //sa7 8
		{10,10,0,0}, //sa8 9
		{11,11,0,0}, //sa9 10
		{12,12,0,0}, //sa10 11
		{13,13,0,0}, //sa11 12
		{14,14,0,0}, //sa12 13 
		{15,15,0,0}, //sa13 14
		{16,16,0,0}, //sa14 15
		{17,17,0,0}, //sa15 16 
		{18,18,0,0}, //sa16 17
		{19,19,0,0}, //sa18 18
		{20,20,0,0}, //sa19 19
		{21,21,0,0}, //sa21 20
		{22,22,0,0}, //sa22 21
		{23,23,0,0}, //sa23 22
		{24,24,0,0}, //sa24 23
		{25,25,0,0}, //sa25 24
		{26,26,0,0}, //sa26 25
		{27,27,0,0}, //sa27 26
		{28,28,0,0}, //sa28 27
		{29,29,0,0}, //sa28bis 28
		{30,30,0,0}, //sa28ter 29
		{31,31,0,0}, //sa29 30
		{32,32,0,0}, //sa30 31
		{33,33,3,1}, //any alert 32
		{34,34,0,0}, //nongenotoxic alerts 33
		{35,36,0,0}, //sa17 34
		{36,36,0,0}, //sa20 35
		{37,37,0,0}, //sa31a 36 
		{38,38,0,0}, //sa31b 37
		{39,39,0,0}, //sa31c 38
		{40,40,3,2}, //any alert 39
		{43,41,0,0}, //Rule 40 a,b aldehyde 40
		{43,42,8,0}, //Rule 41 user input 41
		{43,43,5,4}, //Rule 42 QSAR13 42
		{44,44,0,0}, //Rule 43 aN=Na  - if yes will be split into ar amines, otherwise will work with the original compound 41
		{45,45,0,0}, //Rule 44 (ii)		
		{0,46,0,0}, //Rule 45 ar amine 
		{0,47,8,0}, //Rule 46 user input 
		{48,48,7,6}, //Rule 47 QSAR8 
		{0,0,5,4}, //Rule 48 QSAR6 
		
	};

	
	
	private final static transient String c_categories[] ={
		"mutant.categories.CategoryPositiveAlertGenotoxic", //1
		"mutant.categories.CategoryPositiveAlertNongenotoxic", //2
		"mutant.categories.CategoryNoAlert",		//3
		"mutant.categories.CategoryMutagenTA100",	//4
		"mutant.categories.CategoryNonMutagen",	//5
		"mutant.categories.CategoryCarcinogen",		//6
		"mutant.categories.CategoryNotCarcinogen", //7
		"mutant.categories.QSARApplicable"	//8
	};
	/**
	 * 
	 */
	public MutantRules() throws DecisionMethodException {
		super(new CategoriesList(c_categories,true),c_rules,c_transitions,new DecisionNodesFactory(true));
		/*
		super(new CategoriesList(c_categories),);
		rules = new Mul(categories,c_rules,c_transitions);
		if (rules instanceof Observable) ((Observable)rules).addObserver(this);
		*/
		
		setChanged();
		notifyObservers();
		/*
		if (changes != null ) {
			changes.firePropertyChange("Rules", rules,null);
			changes.firePropertyChange("Transitions", transitions,null);
		}
		*/
		setTitle("Cancerogenicity/Mutagenicity prediction");
		setExplanation(
				"Predicts possibility of cancerogenicity and mutagenicity by discriminant analysis and structural rules" 
				);
        setPriority(20);
        //setFalseIfRuleNotImplemented(false); //this will cause exception if an error occurs in a rule
	}


	/* (non-Javadoc)
     * @see toxTree.core.IDecisionMethod#addPropertyChangeListener(java.beans.PropertyChangeListener)
     */
    public void addPropertyChangeListener(PropertyChangeListener l) {
        if (changes == null) 		changes = new PropertyChangeSupport(this);        
        changes.addPropertyChangeListener(l);
		for (int i=0; i < rules.size(); i++) 
			if (rules.getRule(i) != null)
				rules.getRule(i).addPropertyChangeListener(l);
    }
    /* (non-Javadoc)
     * @see toxTree.core.IDecisionMethod#removePropertyChangeListener(java.beans.PropertyChangeListener)
     */
    public void removePropertyChangeListener(PropertyChangeListener l) {
        if (changes == null) {
	        changes.removePropertyChangeListener(l);
	        for (int i=0; i < rules.size(); i++) 
	        	if (rules.getRule(i) != null)
	        		rules.getRule(i).removePropertyChangeListener(l);
        }	
    }	
    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    public String toString() {
        return getName();
    }
	


	/* (non-Javadoc)
     * @see toxTree.core.IDecisionMethod#getName()
     */
    public String getName() {
        return name;
    }
    /* (non-Javadoc)
     * @see toxTree.core.IDecisionMethod#setName(java.lang.String)
     */
    public void setName(String value) {
       name = value;

    }
	public StringBuffer explainRules(IDecisionResult result,boolean verbose) throws DecisionMethodException{
		try {
			StringBuffer b = result.explain(verbose);
			return b;
		} catch (DecisionResultException x) {
			throw new DecisionMethodException(x);
		}
	}


	@Override
	public IDecisionResult createDecisionResult() {
		IDecisionResult result =  new MutantTreeResult();
		result.setDecisionMethod(this);
		return result;
	}

	public boolean isResiduesIDVisible() {
		return residuesIDVisible;
	}


	public void setResiduesIDVisible(boolean residuesIDVisible) {
		this.residuesIDVisible = residuesIDVisible;
		for (int i=0;i< rules.size(); i++) {
			rules.getRule(i).hideResiduesID(!residuesIDVisible);
		}
	}
	public void setEditable(boolean value) {
		editable = value;
		for (int i=0;i<rules.size();i++)
			rules.getRule(i).setEditable(value);
	}


}


