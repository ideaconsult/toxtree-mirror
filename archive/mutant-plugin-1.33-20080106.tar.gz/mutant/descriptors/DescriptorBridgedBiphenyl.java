package mutant.descriptors;

import org.openscience.cdk.Atom;
import org.openscience.cdk.CDKConstants;
import org.openscience.cdk.exception.CDKException;
import org.openscience.cdk.isomorphism.matchers.IQueryAtom;
import org.openscience.cdk.isomorphism.matchers.QueryAtomContainer;
import org.openscience.cdk.isomorphism.matchers.SymbolQueryAtom;
import org.openscience.cdk.isomorphism.matchers.smarts.AromaticQueryBond;
import org.openscience.cdk.qsar.DescriptorSpecification;

import toxTree.query.TopologyAnyAtom;
import toxTree.query.TopologyOrderQueryBond;

public class DescriptorBridgedBiphenyl extends DescriptorStructurePresence {
	protected static String BiBr = "I(BiBr)";
	protected static QueryAtomContainer bridgedBiphenyl = bridgedBiphenyl(); 
	public DescriptorBridgedBiphenyl() {
		super();
		try {
		setParameters(new Object[] {
				bridgedBiphenyl,
				BiBr}
				);
		} catch (CDKException x) {
			setFragment(null);
			setResultName(BiBr);
			logger.error(x);
		}
	}
	
	 public DescriptorSpecification getSpecification() {
	        return new DescriptorSpecification(
	            "True if contains bridged biphenyl group, false otherwise",
	            this.getClass().getName(),
	            "$Id: DescriptorBridgedBiphenyl.java  2007-08-21 10:31 nina$",
	            "ToxTree Mutant plugin");
	    }
	 /**
	  * Two phenyl rings linked with a bridge (any atom can be on the bridge)
	  * @return
	  */
	 public static QueryAtomContainer bridgedBiphenyl() {
	        QueryAtomContainer query = new QueryAtomContainer() {
	        	@Override
	        	public String toString() {
	        		return getID();
	        	}
	        };
	        query.setID(BiBr);
	        IQueryAtom atomAtBridge = new TopologyAnyAtom(false);
	        query.addAtom(atomAtBridge);
	        

	        //create queries for two aromatic rings
	        for (int r = 0; r < 2; r++) {
	        	SymbolQueryAtom prev = null;
	        	SymbolQueryAtom first = null;
	        	
		        for (int i=0; i < 6; i++) {
		        	SymbolQueryAtom c = new SymbolQueryAtom(new Atom("C"));
		        	query.addAtom(c);
		        	if (first == null) first = c;
		        	if (prev != null) {
		        		query.addBond(new AromaticQueryBond(c, prev,CDKConstants.BONDORDER_SINGLE));
		        	}
		        	prev = c;
		        }
		        query.addBond(new AromaticQueryBond(first, prev,CDKConstants.BONDORDER_SINGLE));
		        
		        query.addBond(new TopologyOrderQueryBond(first, atomAtBridge,CDKConstants.BONDORDER_SINGLE,false));
	        }
	        return query; 
	 }
}
