		package mutant.descriptors;

import org.openscience.cdk.Atom;
import org.openscience.cdk.CDKConstants;
import org.openscience.cdk.exception.CDKException;
import org.openscience.cdk.interfaces.IAtomContainer;
import org.openscience.cdk.interfaces.IAtomContainerSet;
import org.openscience.cdk.interfaces.IBond;
import org.openscience.cdk.isomorphism.matchers.IQueryAtom;
import org.openscience.cdk.isomorphism.matchers.OrderQueryBond;
import org.openscience.cdk.isomorphism.matchers.QueryAtomContainer;
import org.openscience.cdk.isomorphism.matchers.SymbolAndChargeQueryAtom;
import org.openscience.cdk.isomorphism.matchers.SymbolQueryAtom;
import org.openscience.cdk.isomorphism.matchers.smarts.AnyAtom;
import org.openscience.cdk.isomorphism.matchers.smarts.AnyOrderQueryBond;
import org.openscience.cdk.isomorphism.matchers.smarts.AromaticQueryBond;
import org.openscience.cdk.qsar.DescriptorSpecification;
import org.openscience.cdk.qsar.DescriptorValue;
import org.openscience.cdk.qsar.result.DoubleArrayResult;

import toxTree.exceptions.DecisionMethodException;
import toxTree.query.FunctionalGroups;
import toxTree.query.TopologySymbolQueryAtom;
import toxTree.tree.rules.LookupFile;

/**
 * returns "MR","LSTM","B1STM","B5STM" for substituents at postitions 1 to 6 (amine group at 1 position).
 * TODO verify how substituted amine group should be treated (params of amine group + substituent, only substituent, largest substituent, average, etc.)
 * @author Nina Jeliazkova
 *
 */
public class AromaticAmineSubstituentsDescriptor extends SubstituentsDescriptor {
	protected LookupFile lookup;
	
	public AromaticAmineSubstituentsDescriptor() {
		super(aromaticAmine());
		setDescriptorNames(new String[] {"MR","LSTM","B1STM","B5STM"});
		try {
			//lookup = new LookupFile("plugins/v 1.11/mutant/src/mutant/descriptors/substituents.sdf");
			lookup = new LookupFile("substituents.sdf");
			lookup.setUseCache(true);
			lookup.setCheckAromaticity(false);
		} catch (Exception x) {
			logger.error(x);
			lookup = null;
		}
		
	}
	public DescriptorSpecification getSpecification() {
        return new DescriptorSpecification(
                "Molar refractivity and Sterimol descriptors of aromatic amine substituents (at postitions 1 to 6 , where amine group is at 1 position)",
                this.getClass().getName(),
                "$Id: AromaticAmineSubstituentsDescriptor.java 6171 2007-08-06 14:09:00 +0000 (Mon, 06 August 2007) nina $",
                "Toxtree plugin");
	}	
	@Override
	public DescriptorValue calculate(IAtomContainerSet substituents)
			throws CDKException {
		if (lookup == null) throw new CDKException("Substituents list not defined!");
		//one set of values per each position (ortho, meta, para)
		double values[][] = new double[getDescriptorNames().length][6];
		int count[] = new int[getDescriptorNames().length];
		for (int i=0; i < count.length;i++) {
			count[i] = 0;
			//values[i] = new double[6];
			for (int j=0; j <6;j++) values[i][j]=Double.NaN; 
		}
		
		for (int k = 0; k < substituents.getAtomContainerCount(); k++) {
			IAtomContainer m = substituents.getAtomContainer(k);
		    if (m!=null) {
			    //if ((m.getAtomCount() == 1) && (m.getAtom(0).getSymbol().equals("H"))) continue;
			    Object place = null;
			    for (int j=0;j <m.getAtomCount();j++) {
			    	place = m.getAtom(j).getProperty(FunctionalGroups.RING_NUMBERING);
			    	if (place != null)  
			    	//	addValueForSubstituent(m,((Integer) place).intValue(),results);
			    	try {
			    		int p = ((Integer) place).intValue();
			    		IAtomContainer mol = lookup.lookup(m);
			    		if (mol != null) 
			    			for (int i=0; i < getDescriptorNames().length;i++) {
			    				Object d = mol.getProperty(getDescriptorNames()[i]);
			    				if (d != null)
			    					try {
			    						double v = Double.parseDouble(d.toString());
			    						//if (count[i]==0) values[i][0]=v;
			    						//else values[i][0] += v;
			    						
			    						values[i][p-1]= v;
			    						count[i] ++;
			    						if (logger.isDebugEnabled())
			    							logger.debug((mol.getProperty("Group") +" "+mol.getProperty("Position") +" "+getDescriptorNames()[i] + "_" + Integer.toString(p)+ " = " +v));
			    					} catch (NumberFormatException x) {
			    						logger.error(x);
			    					}
			    			}
			    	} catch (DecisionMethodException x) {
			    		logger.error(x);
			    	}
			    } 
		    }
		}

		
		DoubleArrayResult results = new DoubleArrayResult();		
		for (int i=0; i < getDescriptorNames().length;i++) {
			if (count[i]>1) values[i][0] /= count[i];
			//results.add(values[i][0]);
		}
		String[] d = new String[6*getDescriptorNames().length];
		for (int j=0; j < 6;j++)
			for (int i=0; i < getDescriptorNames().length;i++) {
				//if (count[i]>1) values[i][0] /= count[i];
				d[j*getDescriptorNames().length+i] = getDescriptorNames()[i]+Integer.toString(j+1);
				results.add(values[i][j]);
			}		
		return new DescriptorValue(getSpecification(), getParameterNames(),
			getParameters(), results, d );
	}

    public static QueryAtomContainer aromaticAmine() {
        QueryAtomContainer query = new QueryAtomContainer() {
        	@Override
        	public String toString() {
        		return getID();
        	}
        	
        };
        query.setID(FunctionalGroups.AROMATIC_AMINE);
        IQueryAtom[] c = new IQueryAtom[3];
        
        Atom a  = new Atom("N");
        a.setFormalCharge(0);
        
        SymbolAndChargeQueryAtom n = new SymbolAndChargeQueryAtom(a);
        n.setProperty(FunctionalGroups.RING_NUMBERING,new Integer(1));
        query.addAtom(n);
        
        c[0] = new TopologySymbolQueryAtom(new Atom("C"),true);
        c[0].setProperty(FunctionalGroups.RING_NUMBERING,new Integer(1));
        c[1] = new AnyAtom(); c[1].setSymbol("R");
        c[2] = new AnyAtom();c[2].setSymbol("R");
        for (int i=0; i<c.length; i++) {
	        query.addAtom(c[i]);
        	query.addBond(new OrderQueryBond(c[i], n, CDKConstants.BONDORDER_SINGLE));
        }

        IQueryAtom[] ring = new SymbolQueryAtom[3];
        IQueryAtom[] prev = new IQueryAtom[2];
        
        for (int j=0;j<prev.length;j++) {
        	prev[j] = c[0];
        	for (int i=0; i<ring.length; i++) {
        	
        		int p = i+2;
        		if (j > 0) p = 8-p;
        		
        		if ((j>0) && (i==ring.length-1)) break;
		        ring[i] = new TopologySymbolQueryAtom(new Atom("C"),true);
		        ring[i].setProperty(FunctionalGroups.RING_NUMBERING,new Integer(p));
		        query.addAtom(ring[i]);
		        IBond b = new AromaticQueryBond(ring[i], prev[j],CDKConstants.BONDORDER_SINGLE);
		        //IBond b = new SingleOrDoubleQueryBond(ring[i], prev[j]);
	        	query.addBond(b);
	        	
	        	AnyAtom any = new AnyAtom(); any.setSymbol("R");
	        	any.setProperty(FunctionalGroups.RING_NUMBERING,new Integer(p));
	        	query.addAtom(any);
	        	//query.addBond(new TopologyAnyBond(ring[i],any,false));
	        	query.addBond(new AnyOrderQueryBond(ring[i],any,CDKConstants.BONDORDER_SINGLE));
	       	
	        	prev[j] = ring[i];
        	}
        }
        /*
        for (int i=0; i < query.getAtomCount();i++) {
        	System.out.println("Query\t"+query.getAtom(i).getSymbol()+"\t"+query.getAtom(i).getProperty(FunctionalGroups.RING_NUMBERING));
        }
        */	
        
        return query;
    }
	
}
