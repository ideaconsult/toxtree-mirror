package mutant.descriptors;

import java.util.Hashtable;
import java.util.List;

import org.openscience.cdk.DefaultChemObjectBuilder;
import org.openscience.cdk.exception.CDKException;
import org.openscience.cdk.graph.ConnectivityChecker;
import org.openscience.cdk.interfaces.IAtom;
import org.openscience.cdk.interfaces.IAtomContainer;
import org.openscience.cdk.interfaces.IAtomContainerSet;
import org.openscience.cdk.interfaces.IBond;
import org.openscience.cdk.interfaces.IMoleculeSet;
import org.openscience.cdk.interfaces.IRing;
import org.openscience.cdk.interfaces.IRingSet;
import org.openscience.cdk.isomorphism.UniversalIsomorphismTester;
import org.openscience.cdk.isomorphism.matchers.QueryAtomContainer;
import org.openscience.cdk.isomorphism.mcss.RMap;
import org.openscience.cdk.ringsearch.SSSRFinder;

import toxTree.logging.TTLogger;
import toxTree.query.FunctionalGroups;

public class SubstituentExtractor {
	protected QueryAtomContainer ringQuery;
	protected static TTLogger logger = new TTLogger(SubstituentExtractor.class);
	public SubstituentExtractor() {
		this(null);
	}
	public SubstituentExtractor(QueryAtomContainer ringQuery) {
		super();
		setRingQuery(ringQuery);
	}
	/**
	 * Note: Aromaticity flags should already be set before running this method.
	 * @param a
	 * @return
	 * @throws Exception
	 */
	public IAtomContainerSet extractSubstituents(IAtomContainer a) throws CDKException {
		//TODO clean ring numbering
		logger.debug("extract substituents");
		if (ringQuery == null) throw new CDKException("Query not assigned");
		if (markAtomsInRing(a, ringQuery)) {
			IAtom anchor = null;
			for (int i=0; i < a.getAtomCount();i++) {
				IAtom atom = a.getAtom(i);
				//System.out.println(atom.getSymbol() + "\t" + atom.getProperty(FunctionalGroups.RING_NUMBERING));
				if ("C".equals(atom.getSymbol()) &&
						(atom.getProperty(FunctionalGroups.RING_NUMBERING) != null) &&
						atom.getProperty(FunctionalGroups.RING_NUMBERING).equals(1)) 
						anchor = atom;
						
			}	
			SSSRFinder ssrf = new SSSRFinder(a);
			IRingSet rs = ssrf.findSSSR();
			rs = rs.getRings(anchor);
			for (int r=0; r < rs.getAtomContainerCount();r++) {
		        IAtomContainer mc = cloneDiscardRingAtomAndBonds(a,(IRing)rs.getAtomContainer(r));
		        IMoleculeSet  s = ConnectivityChecker.partitionIntoMolecules(mc);
				return s;	
				//int substituents = enumerateSubstituents(s);
			}
			return null;
		} else 
			throw new CDKException(ringQuery.toString() + "\t not found.");
	}
	
	public static boolean markAtomsInRing(IAtomContainer mol, QueryAtomContainer q) throws CDKException{
		//try {
			List list = UniversalIsomorphismTester.getSubgraphAtomsMap(mol,q);
			if (list != null) {
				for (int i=0; i < list.size();i++) {
					RMap map = (RMap)list.get(i);
					if (map.getId2()>=0) {
						//System.out.print("Atom\t" + mol.getAtom(map.getId1()).getSymbol());
						Object p = q.getAtom(map.getId2()).getProperty(FunctionalGroups.RING_NUMBERING);
						if (p != null) {
							//System.out.println("\tNumber\t"+p);
							mol.getAtom(map.getId1()).setProperty(FunctionalGroups.RING_NUMBERING,p);
						} 
						//elseSystem.out.println();
					}
				}
				return true;
			}	
			else return false;
			/*
		} catch (CDKException x) {
			logger.debug(x);
		}
		*/
		
	}
	
    public static IAtomContainer cloneDiscardRingAtomAndBonds(
    		IAtomContainer ac, IRing ring ) {
        IAtomContainer result = new org.openscience.cdk.AtomContainer();
        Hashtable<IAtom,IAtom> table = new Hashtable<IAtom,IAtom>();
        for (int i =0; i < ac.getAtomCount(); i++) {
        	IAtom a = ac.getAtom(i);
            if (ring.contains(a)) {
            	//if (!a.getSymbol().equals("C")) continue;
            	continue;
            }
            //Atom newAtom = (Atom) a.clone();
            table.put(a,a);
            result.addAtom(a);
        }
        
        for (int i =0; i < ac.getBondCount(); i++) {
            IBond b = ac.getBond(i);
            
            
            IAtom a1 = (IAtom) table.get(b.getAtom(0));
            IAtom a2 = (IAtom) table.get(b.getAtom(1));
            
            if ((a1 != null) && (a2 != null)) 
            	result.addBond(b);
            else {
            	
            	IAtom a = null;
            	if (a1 != null) a = a1;
            	else if (a2 != null) a = a2;
	            	
	            if (a != null) {
	            	logger.debug("Substituent starting with "+a.getSymbol());
	            	IAtom r = DefaultChemObjectBuilder.getInstance().newAtom("R");
	            	result.addAtom(r);
	            	result.addBond(DefaultChemObjectBuilder.getInstance().
	            			newBond(a, r, b.getOrder()));
	            }
            }
        }
        return result;
    }    
	
	public QueryAtomContainer getRingQuery() {
		return ringQuery;
	}
	public void setRingQuery(QueryAtomContainer ringQuery) {
		this.ringQuery = ringQuery;
	}

}
