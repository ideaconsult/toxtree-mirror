/*
Copyright Ideaconsult Ltd. (C) 2005-2007  

Contact: nina@acad.bg

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2.1
of the License, or (at your option) any later version.
All we ask is that proper credit is given for our work, which includes
- but is not limited to - adding the above copyright notice to the beginning
of your source code files, and to any copyright notice that you may distribute
with programs based on this work.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA
*/

package mutant.descriptors;

import joelib.molecule.JOEMol;

import org.openscience.cdk.exception.CDKException;
import org.openscience.cdk.interfaces.IAtomContainer;
import org.openscience.cdk.interfaces.IMolecule;
import org.openscience.cdk.qsar.DescriptorSpecification;
import org.openscience.cdk.qsar.DescriptorValue;
import org.openscience.cdk.qsar.IMolecularDescriptor;
import org.openscience.cdk.qsar.result.IDescriptorResult;
import org.openscience.cdk.qsar.result.IntegerResult;

import toxTree.tree.rules.smarts.Convertor;
import toxTree.tree.rules.smarts.SMARTSException;
import toxTree.tree.rules.smarts.SmartsPattern;

/**
 * Returns Idist = 1, otherwise Idist = 0) if substituents on the positions 3-, 4- and 5- of 4-aminobiphenyl are present r
 * if substituent is present at position 7- of 2-aminofluorene (e.g.: 4'-nButyl-4-aminobiphenyl; 4'-tButyl-4-aminobiphenyl;	4'-Trifluoromethyl-4-aminobiphenyl; 3'-Trifluoromethyl-4-aminobiphenyl).;

 * 		//[*]C1=CC(=CC([*])=C1([*]))C2=CC=C(N)C=C2  substituents on the positions 3-, 4- and 5- of 4-aminobiphenyl
		//[*]C1=CC=C3C(=C1)C=C2CC(N)C=CC23  subst at position 7- of 2-aminofluorene
 * @author Nina Jeliazkova
 *
 */
public class DescriptorIDist implements IMolecularDescriptor {
	protected String[] names = {"Idist"};
	protected SmartsPattern[] smarts= null;
	
	public DescriptorIDist() {
		super();
		smarts = new SmartsPattern[3];
		try {
			smarts[0] = new SmartsPattern("[!$([#1])]c1ccc(cc1)c2ccc(N)cc2");
			smarts[1] = new SmartsPattern("[!$([#1])]c1cccc(c1)c2ccc(N)cc2");
			
			smarts[2] = new SmartsPattern("[!$([#1])]c3ccc1c(C=C2CC(N)C=CC12)c3");
		} catch (Exception x) {
			smarts = null;
		}

	}
	
	public DescriptorValue calculate(IAtomContainer arg0) throws CDKException {
		if (smarts == null) throw new CDKException("Substructure not assigned!");

		if (arg0 instanceof IMolecule) {
			JOEMol mol = Convertor.convert((IMolecule)arg0);
	        
			int ok = 0;
			try {
				for (int i=0; i < smarts.length;i++) 
					if (smarts[i].hasSMARTSPattern(mol)>0) {
						ok = 1;
						break;
					}
				
		        return new DescriptorValue(getSpecification(), getParameterNames(), getParameters(),
		                new IntegerResult(ok), names);
			} catch (SMARTSException x) {
				throw new CDKException(x.getMessage());
			}
		} else throw new CDKException("IMolecule expected!");
	}

	public IDescriptorResult getDescriptorResultType() {
		return new IntegerResult(0);
	}

	public String[] getParameterNames() {
		return null;
	}

	public Object getParameterType(String arg0) {
		return null;
	}

	public Object[] getParameters() {
		return null;
	}

	public DescriptorSpecification getSpecification() {
        return new DescriptorSpecification(
	            "ToxTree Mutant plugin",
	            this.getClass().getName(),
	            "$Id: DescriptorIDist.java  2007-08-21 12:59 nina$",
	            "ToxTree Mutant plugin");
	}

	public void setParameters(Object[] arg0) throws CDKException {
		throw new CDKException("No parameters are expected!");

	}

}
