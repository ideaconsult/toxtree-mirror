/*
Copyright Ideaconsult Ltd.(C) 2006  
Contact: nina@acad.bg

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

*/
package eye.rules;

import sicret.rules.RuleLogP;

/**
 * LogKow > 5.5
 * @author Nina Jeliazkova
 *
 */
public class RuleLogP_9_4 extends RuleLogP {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3681268707976233188L;

	public RuleLogP_9_4()
	{
		super(LogKow,"",condition_higher,4.5);
		setID("9.4");
		examples[0] = "C1(C(C(=O)NC(N1)=O)(c2ccccc2)CC)=O";
		examples[1] = "c2(c(Nc1c(c(C)ccc1)C)cccc2)C(=O)O";			
		
	}


}
