/*
Copyright Ideaconsult Ltd.(C) 2006  
Contact: nina@acad.bg

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

*/
package sicret.rules;

import org.openscience.cdk.Molecule;

import toxTree.exceptions.DecisionMethodException;
import toxTree.query.FunctionalGroups;

/**
 * 
 * LogKow < 0.5
 *
 */
public class Rule28  extends RuleLogP {
	
	private static final long serialVersionUID = 0;
	public Rule28()
	{
		super(LogKow,"",condition_lower,0.5);
		id = "32";
	}
	public Molecule getExampleMolecule(boolean ruleResult) throws DecisionMethodException {
		Molecule m = new Molecule();        
        if (ruleResult){
        	
        		m = (Molecule)FunctionalGroups.createAtomContainer("O=C(O)c1ccsc1NC=O",false);
    			m.setProperty(LogKow, 0.452724576585533);
        }
    	else {
    		m = (Molecule)FunctionalGroups.createAtomContainer("Cc1cc(cc(C)c1N)N(=O)=O",false);
        		m.setProperty(LogKow, 2.03426733210718);
    	}      	
		return m;
	}

}
